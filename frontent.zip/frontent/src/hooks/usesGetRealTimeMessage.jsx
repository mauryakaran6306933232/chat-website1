// import {useEffect} from "react";
// import store from "../redux/store";
// import {useSelector , useDispatch} from 'react-redux'
// import { addMessage, setMessageSlice } from "../redux/messageSlice";
// const  useGetRealTimeMessage = () =>{
//  const dispatch = useDispatch(); 
// const   {message } = useSelector(store=>store.message)
//  const {socket} = useSelector(store=>store.socket);
// //  useEffect(()=>{
// //     socket?.on('newMessage',(p1)=>{
// //         console.log("new message is",p1);
// //         dispatch(setMessageSlice([...message, p1]))
// //         // dispatch(addMessage(p1))
// //     })
// //  },[socket, message ])
// useEffect(() => {
//   if (!socket) return;

//   const handler = (p1) => {
//     console.log("new message is", p1);
//     console.log('message from socket',message)
//     if(message==null)
//     {
//       dispatch(setMessageSlice([p1]))
//     }
//     else{
//       dispatch(addMessage(p1));
//     }
//     // dispatch(addMessage(p1));
//   };

//   socket.on("newMessage", handler);

//   return () => {
//     socket.off("newMessage", handler);  // ✅ cleanup old listeners
//   };
// }, [socket , setMessageSlice, message]);

// }
// export default useGetRealTimeMessage
// import { useEffect } from "react";
// import store from "../redux/store";
// import { useSelector, useDispatch } from 'react-redux'
// import { addMessage, setMessageSlice } from "../redux/messageSlice";
// import axios from "axios"; // <--- ADD AXIOS IMPORT

// const useGetRealTimeMessage = (selectedUser) => {
//   const dispatch = useDispatch();
//   const { socket } = useSelector(store => store.socket);
//   const { authUser } = useSelector(store => store.user);

//   useEffect(() => {
//     if (!socket) return;

//     // ==========================================
//     // 1. HANDLE NEW MESSAGES
//     // ==========================================
//     const messageHandler = (p1) => {
//       const isForActiveChat = selectedUser?._id === p1.senderId || selectedUser?._id === p1.receiverId;
      
//       if (!isForActiveChat) return;

//       const currentMessages = store.getState().message.message;
//       if (currentMessages == null) {
//         dispatch(setMessageSlice([p1]))
//       } else {
//         dispatch(addMessage(p1));
//       }

//       // ==========================================
//       // 🔥 NEW: MARK AS READ INSTANTLY
//       // If someone sends US a message while we are looking at their chat, mark it read immediately!
//       // ==========================================
//       if (p1.senderId === selectedUser?._id) {
//         axios.post(`http://localhost:8001/test/mark-read/${selectedUser._id}`, {}, { withCredentials: true })
//           .catch(err => console.log("Realtime mark read error:", err));
//       }
//     };

//     // ==========================================
//     // 2. HANDLE DELETED MESSAGES
//     // ==========================================
//     const deleteHandler = (messageId) => {
//       const currentMessages = store.getState().message.message || [];
//       const updatedMessages = currentMessages.map(msg =>
//         msg._id === messageId
//           ? { ...msg, message: "This message was deleted", fileUrl: "", fileType: "", deletedForEveryone: true }
//           : msg
//       );
//       dispatch(setMessageSlice(updatedMessages));
//     };

//     // ==========================================
//     // 3. HANDLE MESSAGE READ (BLUE TICKS)
//     // ==========================================
//     const readHandler = ({ receiverId }) => {
//       const currentMessages = store.getState().message.message || [];
//       const updatedMessages = currentMessages.map(msg => {
//         if (msg.senderId === authUser?._id && msg.receiverId === receiverId) {
//           if (!msg.readBy?.includes(receiverId)) {
//             return { ...msg, readBy: [...(msg.readBy || []), receiverId] };
//           }
//         }
//         return msg;
//       });
//       dispatch(setMessageSlice(updatedMessages));
//     };

//     // REGISTER LISTENERS
//     socket.on("newMessage", messageHandler);
//     socket.on("messageDeleted", deleteHandler);
//     socket.on("messageRead", readHandler);

//     // Cleanup
//     return () => {
//       socket.off("newMessage", messageHandler);
//       socket.off("messageDeleted", deleteHandler);
//       socket.off("messageRead", readHandler);
//     };
    
//   }, [socket, authUser?._id, dispatch, selectedUser?._id]);
// }

// export default useGetRealTimeMessage;
// import { useEffect } from "react";
// import store from "../redux/store";
// import { useSelector, useDispatch } from 'react-redux'
// import { addMessage, setMessageSlice } from "../redux/messageSlice";
// import { incrementUnread } from "../redux/UserSlice"; // <--- 1. ADD THIS IMPORT
// import axios from "axios";

// const useGetRealTimeMessage = (selectedUser) => {
//   const dispatch = useDispatch();
//   const { socket } = useSelector(store => store.socket);
//   const { authUser } = useSelector(store => store.user);

//   useEffect(() => {
//     if (!socket) return;

//     // ==========================================
//     // 1. HANDLE NEW MESSAGES
//     // ==========================================
//     const messageHandler = (p1) => {
//       const isForActiveChat = selectedUser?._id === p1.senderId || selectedUser?._id === p1.receiverId;
      
//       if (!isForActiveChat) {
//         // ==========================================
//         // 🔥 NEW: BADGE LOGIC (Add this block)
//         // If the message is NOT for the open chat, AND it was sent TO me, increase badge!
//         // ==========================================
//         if (p1.receiverId === authUser?._id) {
//           console.log("1. BEFORE DISPATCH:", store.getState().user.unreadCounts);
//           dispatch(incrementUnread(p1.senderId));
//             console.log("2. AFTER DISPATCH:", store.getState().notifications.unreadCounts);
//              setTimeout(() => {
//             console.log("3. ONE SECOND LATER:", store.getState().notifications.unreadCounts);
//           }, 1000);
//           console.log("🔥 BADGE FIRED FOR USER: ", p1.senderId);
//         }
//         return; // Keep your original return early!
//       }

//       const currentMessages = store.getState().message.message;
//       if (currentMessages == null) {
//         dispatch(setMessageSlice([p1]))
//       } else {
//         dispatch(addMessage(p1));
//       }

//       // ==========================================
//       // MARK AS READ INSTANTLY
//       // ==========================================
//       if (p1.senderId === selectedUser?._id) {
//         axios.post(`http://localhost:8001/test/mark-read/${selectedUser._id}`, {}, { withCredentials: true })
//           .catch(err => console.log("Realtime mark read error:", err));
//       }
//     };

//     // ==========================================
//     // 2. HANDLE DELETED MESSAGES
//     // ==========================================
//     const deleteHandler = (messageId) => {
//       const currentMessages = store.getState().message.message || [];
//       const updatedMessages = currentMessages.map(msg =>
//         msg._id === messageId
//           ? { ...msg, message: "This message was deleted", fileUrl: "", fileType: "", deletedForEveryone: true }
//           : msg
//       );
//       dispatch(setMessageSlice(updatedMessages));
//     };

//     // ==========================================
//     // 3. HANDLE MESSAGE READ (BLUE TICKS)
//     // ==========================================
//     const readHandler = ({ receiverId }) => {
//       const currentMessages = store.getState().message.message || [];
//       const updatedMessages = currentMessages.map(msg => {
//         if (msg.senderId === authUser?._id && msg.receiverId === receiverId) {
//           if (!msg.readBy?.includes(receiverId)) {
//             return { ...msg, readBy: [...(msg.readBy || []), receiverId] };
//           }
//         }
//         return msg;
//       });
//       dispatch(setMessageSlice(updatedMessages));
//     };

//     // REGISTER LISTENERS
//     socket.on("newMessage", messageHandler);
//     socket.on("messageDeleted", deleteHandler);
//     socket.on("messageRead", readHandler);

//     // Cleanup
//     return () => {
//       socket.off("newMessage", messageHandler);
//       socket.off("messageDeleted", deleteHandler);
//       socket.off("messageRead", readHandler);
//     };
    
//   }, [socket, authUser?._id, dispatch, selectedUser?._id]);
// }

// export default useGetRealTimeMessage;
import { useEffect } from "react";
import store from "../redux/store";
import { useSelector, useDispatch } from 'react-redux'
import { addMessage, setMessageSlice } from "../redux/messageSlice";
import { incrementUnread } from "../redux/UserSlice"; // Points to UserSlice now
import axios from "axios";

const useGetRealTimeMessage = (selectedUser) => {
  const dispatch = useDispatch();
  const { socket } = useSelector(store => store.socket);
  const { authUser } = useSelector(store => store.user);

  useEffect(() => {
    if (!socket) return;

    const messageHandler = (p1) => {
      const isForActiveChat = selectedUser?._id === p1.senderId || selectedUser?._id === p1.receiverId;
      
      if (!isForActiveChat) {
        if (p1.receiverId === authUser?._id) {
          // Dispatches to UserSlice now!
          dispatch(incrementUnread(p1.senderId)); 
        }
        return; 
      }

      const currentMessages = store.getState().message.message;
      if (currentMessages == null) {
        dispatch(setMessageSlice([p1]))
      } else {
        dispatch(addMessage(p1));
      }

      if (p1.senderId === selectedUser?._id) {
        axios.post(`http://localhost:8001/test/mark-read/${selectedUser._id}`, {}, { withCredentials: true })
          .catch(err => console.log("Realtime mark read error:", err));
      }
    };

    const deleteHandler = (messageId) => {
      const currentMessages = store.getState().message.message || [];
      const updatedMessages = currentMessages.map(msg =>
        msg._id === messageId
          ? { ...msg, message: "This message was deleted", fileUrl: "", fileType: "", deletedForEveryone: true }
          : msg
      );
      dispatch(setMessageSlice(updatedMessages));
    };

    const readHandler = ({ receiverId }) => {
      const currentMessages = store.getState().message.message || [];
      const updatedMessages = currentMessages.map(msg => {
        if (msg.senderId === authUser?._id && msg.receiverId === receiverId) {
          if (!msg.readBy?.includes(receiverId)) {
            return { ...msg, readBy: [...(msg.readBy || []), receiverId] };
          }
        }
        return msg;
      });
      dispatch(setMessageSlice(updatedMessages));
    };

    socket.on("newMessage", messageHandler);
    socket.on("messageDeleted", deleteHandler);
    socket.on("messageRead", readHandler);

    return () => {
      socket.off("newMessage", messageHandler);
      socket.off("messageDeleted", deleteHandler);
      socket.off("messageRead", readHandler);
    };
    
  }, [socket, authUser?._id, dispatch, selectedUser?._id]);
}

export default useGetRealTimeMessage;