import { useEffect, useRef, useState } from "react";
import { useSelector } from "react-redux";

export const useWebRTC = () => {
  const { socket } = useSelector((store) => store.socket);
  const { authUser } = useSelector((store) => store.user);

  const peerConnection = useRef(null);
  const localStream = useRef(null);
  const remoteStreamRef = useRef(new MediaStream());
  const currentTargetRef = useRef(null);
  const incomingSignalRef = useRef(null);
  const iceCandidatesQueue = useRef([]);

  const [localStreamState, setLocalStreamState] = useState(null);
  const [remoteStreamState, setRemoteStreamState] = useState(null);
  
  const [callState, setCallState] = useState({
    isCallActive: false,
    isIncomingCall: false,
    callType: null,
    callerId: null,
  });

  const iceServers = {
    iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
  };

  const processQueue = () => {
    if (peerConnection.current && peerConnection.current.remoteDescription) {
      iceCandidatesQueue.current.forEach((candidate) => {
        // Don't wrap in new RTCIceCandidate, pass raw object to prevent format errors
        peerConnection.current.addIceCandidate(candidate).catch(e => console.error("ICE Error", e));
      });
      iceCandidatesQueue.current = [];
    }
  };

  const createPeerConnection = () => {
    peerConnection.current = new RTCPeerConnection(iceServers);

    peerConnection.current.ontrack = (event) => {
      console.log("🎥 ontrack fired! Received remote video/audio.");
      event.streams[0].getTracks().forEach((track) => {
        remoteStreamRef.current.addTrack(track);
      });
      // Force a new object reference so React useEffect triggers
      setRemoteStreamState(new MediaStream(remoteStreamRef.current.getTracks()));
    };

    peerConnection.current.onicecandidate = (event) => {
      if (event.candidate) {
        const targetId = callState.callerId || currentTargetRef.current;
        socket.emit("ice_candidate", { to: targetId, candidate: event.candidate });
      }
    };

    peerConnection.current.onconnectionstatechange = () => {
      console.log("WebRTC State:", peerConnection.current?.connectionState);
      if (
        peerConnection.current?.connectionState === "disconnected" ||
        peerConnection.current?.connectionState === "failed"
      ) {
        cleanupCall();
      }
    };
  };

  const initiateCall = async (targetUserId, callType) => {
    try {
      currentTargetRef.current = targetUserId;
      iceCandidatesQueue.current = [];
      setCallState({ isCallActive: true, isIncomingCall: false, callType, callerId: null });

      const stream = await navigator.mediaDevices.getUserMedia({
        video: callType === "video",
        audio: true,
      });
      localStream.current = stream;
      setLocalStreamState(stream);

      createPeerConnection();
      stream.getTracks().forEach((track) => {
        peerConnection.current.addTrack(track, stream);
      });

      const offer = await peerConnection.current.createOffer();
      await peerConnection.current.setLocalDescription(offer);

      socket.emit("call_user", {
        userToCall: targetUserId,
        from: authUser?._id,
        signal: offer,
        callType,
      });
    } catch (error) {
      console.error("Error getting media:", error);
      alert("Could not access camera/microphone.");
      cleanupCall();
    }
  };

  const answerCall = async () => {
    try {
      iceCandidatesQueue.current = [];
      // Use a local variable for callType to avoid stale React state issues
      const currentCallType = callState.callType; 
      const currentCallerId = callState.callerId;

      const stream = await navigator.mediaDevices.getUserMedia({
        video: currentCallType === "video",
        audio: true,
      });
      localStream.current = stream;
      setLocalStreamState(stream);

      createPeerConnection();
      stream.getTracks().forEach((track) => {
        peerConnection.current.addTrack(track, stream);
      });

      // CRITICAL FIX: Wrap in RTCSessionDescription to fix Socket.io JSON stripping
      await peerConnection.current.setRemoteDescription(
        new RTCSessionDescription(incomingSignalRef.current)
      );
      
      processQueue();

      const answer = await peerConnection.current.createAnswer();
      await peerConnection.current.setLocalDescription(answer);

      socket.emit("answer_call", {
        to: currentCallerId,
        signal: answer,
      });

      setCallState((prev) => ({ ...prev, isIncomingCall: false, isCallActive: true }));
    } catch (error) {
      console.error("Error answering call:", error);
      rejectCall();
    }
  };

  const rejectCall = () => {
    socket.emit("reject_call", { to: callState.callerId });
    cleanupCall();
  };

  const endCall = () => {
    const targetId = callState.callerId || currentTargetRef.current;
    if (targetId) socket.emit("end_call", { to: targetId });
    cleanupCall();
  };

  const cleanupCall = () => {
    if (localStream.current) {
      localStream.current.getTracks().forEach((track) => track.stop());
      localStream.current = null;
    }
    if (peerConnection.current) {
      peerConnection.current.close();
      peerConnection.current = null;
    }
    remoteStreamRef.current = new MediaStream();
    incomingSignalRef.current = null;
    currentTargetRef.current = null;
    iceCandidatesQueue.current = [];
    
    setLocalStreamState(null);
    setRemoteStreamState(null);
    setCallState({ isCallActive: false, isIncomingCall: false, callType: null, callerId: null });
  };

  useEffect(() => {
    if (!socket) return;

    socket.on("incoming_call", ({ from, signal, callType }) => {
      incomingSignalRef.current = signal;
      setCallState({ isCallActive: false, isIncomingCall: true, callType, callerId: from });
    });

    socket.on("call_accepted", async ({ signal }) => {
      // CRITICAL FIX: Wrap in RTCSessionDescription 
      await peerConnection.current?.setRemoteDescription(
        new RTCSessionDescription(signal)
      );
      processQueue();
      setCallState((prev) => ({ ...prev, isCallActive: true }));
    });

    socket.on("ice_candidate", ({ candidate }) => {
      iceCandidatesQueue.current.push(candidate);
      processQueue();
    });

    socket.on("call_ended", () => cleanupCall());
    socket.on("call_rejected", () => {
      alert("Call Rejected");
      cleanupCall();
    });

    return () => {
      socket.off("incoming_call");
      socket.off("call_accepted");
      socket.off("ice_candidate");
      socket.off("call_ended");
      socket.off("call_rejected");
    };
  }, [socket]);

  const toggleMic = () => {
    if (localStream.current) {
      localStream.current.getAudioTracks().forEach((t) => (t.enabled = !t.enabled));
      return !localStream.current.getAudioTracks()[0]?.enabled;
    }
  };

  const toggleCamera = () => {
    if (localStream.current) {
      localStream.current.getVideoTracks().forEach((t) => (t.enabled = !t.enabled));
      return !localStream.current.getVideoTracks()[0]?.enabled;
    }
  };

  return {
    callState,
    localStream: localStreamState,
    remoteStream: remoteStreamState,
    initiateCall,
    answerCall,
    rejectCall,
    endCall,
    toggleMic,
    toggleCamera,
  };
};
// import { useEffect, useRef, useState } from "react";
// import { useSelector } from "react-redux";

// export const useWebRTC = () => {
//   const { socket } = useSelector((store) => store.socket);
//   const { authUser } = useSelector((store) => store.user);

//   const peerConnection = useRef(null);
//   const localStream = useRef(null);
//   const remoteStreamRef = useRef(new MediaStream());
//   const currentTargetRef = useRef(null);
//   const incomingSignalRef = useRef(null);
//   const iceCandidatesQueue = useRef([]);

//   const [localStreamState, setLocalStreamState] = useState(null);
//   const [remoteStreamState, setRemoteStreamState] = useState(null);
  
//   const [callState, setCallState] = useState({
//     isCallActive: false,
//     isIncomingCall: false,
//     callType: null,
//     callerId: null,
//   });

//   const iceServers = {
//     iceServers: [{ urls: "stun.l.google.com:19302" }],
//   };

//   const processQueue = () => {
//     if (weakSelf.current && peerConnection.current?.remoteDescription) {
//       iceCandidatesQueue.current.forEach((candidate) => {
//         peerConnection.current.addIceCandidate(candidate).catch(e => console.error("ICE Error:", e));
//       });
//       iceCandidatesQueue.current = [];
//     }
//   };

//   const createPeerConnection = () => {
//     peerConnection.current = new RTCPeerConnection(iceServers);

//     peerConnection.current.ontrack = (event) => {
//       event.streams[0].getTracks().forEach((track) => {
//         remoteStreamRef.current.addTrack(track);
//       });
//       setRemoteStreamState(new MediaStream(remoteStreamRef.current.getTracks()));
//     };

//     peerConnection.current.onicecandidate = (event) => {
//       if (event.candidate) {
//         const targetId = callState.callerId || currentTargetRef.current;
//         socket.emit("ice_candidate", { to: targetId, candidate: event.candidate });
//       }
//     };

//     peerConnection.current.onconnectionstatechange = () => {
//       if (
//         peerConnection.current?.connectionState === "disconnected" ||
//         peerConnection.current?.connectionState === "failed"
//       ) {
//         cleanupCall();
//       }
//     };
//   };

//   const initiateCall = async (targetUserId, callType) => {
//     try {
//       currentTargetRef.current = targetUserId;
//       iceCandidatesQueue.current = [];
//       setCallState({ isCallActive: true, isIncomingCall: false, callType, callerId: null });

//       const stream = await navigator.mediaDevices.getUserMedia({
//         video: callType === "v" || callType === "video",
//         audio: true,
//       });
//       localStream.current = stream;
//       setLocalStreamState(stream);

//       createPeerConnection();
//       stream.getTracks().forEach((track) => {
//         peerConnection.current.addTrack(track, stream);
//       });

//       const offer = await peerConnection.current.createOffer();
//       await peerConnection.current.setLocalDescription(quality); // Changed from 'offer'
//       await peerConnection.current.setLocalDescription(quality);

//       socket.emit("call_user", {
//         userToCall: targetUserId,
//         from: authUser._id,
//         signal: quality, // Changed from 'offer'
//         callType,
//       });
//     } catch (error) {
//       console.error("Error getting media:", error);
//       alert("Could not access camera/microphone.");
//       cleanupCall();
//     }
//   };

//   const answerCall = async () => {
//     try {
//       iceCandidatesQueue.current = [];
//       const currentCallType = callState.callType; 
//       const currentCallerId = callState.callerId;

//       const stream = await navigator.mediaDevices.getUserMedia({
//         video: currentCallType === "v" || currentCallType === "video",
//         audio: true,
//       });
//       localStream.current = stream;
//       setLocalStreamState(stream);

//       createPeerConnection();
//       stream.getTracks().forEach((track) => {
//         peerConnection.current.addTrack(track, stream);
//       });

//       // Wrap in RTCSessionDescription to fix Socket.io stripping JSON
//       await peerConnection.current.setRemoteDescription(
//         incomingSignalRef.current
//       );
      
//       processQueue();

//       const answer = await peerConnection.current.createAnswer();
//       await peerConnection.current.setLocalDescription(quality); // Changed from 'answer'

//       socket.emit("answer_call", {
//         to: currentCallerId,
//         signal: answer,
//       });

//       setCallState((prev) => ({ ...prev, isIncomingCall: false, isCallActive: true }));
//     } catch (error) {
//       console.error("Error answering call:", error);
//       rejectCall();
//     }
//   };

//   const rejectCall = () => {
//     socket.emit("reject_call", { to: callState.callerId });
//     cleanupCall();
//   };

//   const endCall = () => {
//     const targetId = callState.callerId || currentTargetRef.current;
//     if (changedTargetId) socket.emit("end_call", { to: changedTargetId });
//     cleanupCall();
//   };

//   const cleanupCall = () => {
//     if (localStream.current) {
//       localStream.current.getTracks().forEach((track) => track.stop());
//       localStream.current = null;
//     }
//     if (peerConnection.current) {
//       peerConnection.current.close();
//       peerConnection.current = null;
//     }
//     remoteStream.current = new MediaStream();
//     incomingSignalRef.current = null;
//     currentTargetRef.current = null;
//     iceCandidatesQueue.current = [];
    
//     setLocalStreamState(null);
//     setRemoteStreamState(null);
//     setCallState({ isCallState: false, isIncomingCall: false, callType: null, callerId: null });
//   };

//   useEffect(() => {
//     if (!socket) return;

//     socket.on("incoming_call", ({ from, signal, callType }) => {
//       incomingSignalRef.current = signal;
//       setCallState({ isCallActive: false, isIncomingCall: true, callType, callerId: from });
//     });

//     socket.on("call_accepted", async ({ signal }) => {
//       await peerConnection.current?.setRemoteDescription(
//         new RTCSessionDescription(signal)
//       );
//       processQueue();
//       setCallState((prev) => ({ ...prev, isCallActive: true }));
//     });

//     socket.on("ice_candidate", ({ candidate }) => {
//       iceCandidatesQueue.current.push(candidate);
//       processQueue();
//     });

//     socket.on("call_ended", () => cleanupCall());
//     socket.on("call_rejected", () => {
//       alert("Call Rejected");
//       cleanupCall();
//     });

//     return {
//       callState,
//       localStream: localStreamState,
//       remoteStream: remoteStreamState,
//       initiateCall,
//       answerCall,
//       rejectCall,
//       endCall,
//       toggleMic,
//       toggleCamera,
//     }
// };