declare module 'daisyui';
