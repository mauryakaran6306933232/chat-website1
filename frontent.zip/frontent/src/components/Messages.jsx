// import React from 'react'
// import Message from './Message'
// import { useSelector } from 'react-redux'
// import useGetMessages from '../hooks/useGetMessages'
// import Store from '../redux/store'
// import useGetRealTimeMessage from '../hooks/usesGetRealTimeMessage'
// export default function Messages() {
//     ////
//      const {selectedUser} = useSelector(Store=>Store?.user);
//       useGetMessages(selectedUser);
//       useGetRealTimeMessage();
//      const {message} = useSelector(Store=>Store?.message)
//      if(!message){
//         console.log("There is no message", message);
//         return;
//      }
//     console.log("message is", message);
//     return (
//         <div className='px-4 flex-1 overflow-auto'>
//             {
//                 message?.map((message)=>{
//                     return (
//                       <Message key={message?._id} message={message}/>
//                     )
//                 })
//             }
//         </div>
//     )
// }
// import React from 'react'
// import Message from './Message'
// import { useSelector } from 'react-redux'
// import useGetMessages from '../hooks/useGetMessages'
// import Store from '../redux/store'
// import useGetRealTimeMessage from '../hooks/usesGetRealTimeMessage' // I kept your exact spelling with the 's'

// export default function Messages() {
//      const {selectedUser} = useSelector(Store=>Store?.user);
     
//      useGetMessages(selectedUser);
//      useGetRealTimeMessage(selectedUser); // <--- 🔥 PASS selectedUser HERE!
     
//      const {message} = useSelector(Store=>Store?.message)
     
//      if(!message){
//         return null; // Cleaned up the console.log
//      }

//     return (
//         <div className='px-4 flex-1 overflow-y-auto'>
//             {
//                 message?.map((msg)=>{
//                     return (
//                       <Message key={msg?._id} message={msg}/>
//                     )
//                 })
//             }
//         </div>
//     )
// }
import React from 'react'
import Message from './Message'
import { useSelector } from 'react-redux'
import useGetMessages from '../hooks/useGetMessages'
import Store from '../redux/store'
import useGetRealTimeMessage from '../hooks/usesGetRealTimeMessage'

export default function Messages() {
    // Added authUser to get the username for the welcome screen
    const { selectedUser, authUser } = useSelector(Store => Store?.user);
    
    useGetMessages(selectedUser);
    useGetRealTimeMessage(selectedUser); 
    
    const { message } = useSelector(Store => Store?.message)
    
    // ==========================================
    // FIX: Show welcome screen if messages are null OR empty
    // ==========================================
    if (!message || message.length === 0) {
        return (
            <div className='min-w-0 w-full h-full flex flex-col items-center justify-center px-4 py-6 text-center bg-slate-800/50 rounded-lg m-2'>
                <div className="text-6xl mb-4">💬</div>
                <div>
                    <h1 className='text-3xl font-bold text-white sm:text-4xl'>Hi, {authUser?.username}</h1>
                </div>
                <h1 className='mt-3 text-xl text-white/80 sm:text-2xl'>Let&apos;s start the conversation.</h1>
            </div>
        )
    }

    return (
        <div className='px-4 flex-1 overflow-y-auto'>
            {
                message?.map((msg) => {
                    return (
                      <Message key={msg?._id} message={msg}/>
                    )
                })
            }
        </div>
    )
}