// import React, { useState , useEffect} from 'react'
// import SendInput from './SendInput'
// import Messages from './Messages'
// import Store from '../redux/store'
// import { useSelector , useDispatch } from 'react-redux'
// import { setSelectedUser } from '../redux/UserSlice'

// export default function MesssageContainer() {
//     const dispatch = useDispatch();
//     const {selectedUser ,authUser}=useSelector(Store=>Store.user);
//     const getAvatarUrl = (user) => {
//         const seed = encodeURIComponent(user?.username || user?._id || 'user');
//         if (user?.gender?.toLowerCase() === 'male') {
//             return `https://api.dicebear.com/6.x/bottts/svg?seed=male-${seed}`;
//         }
//         if (user?.gender?.toLowerCase() === 'female') {
//             return `https://api.dicebear.com/6.x/bottts/svg?seed=female-${seed}`;
//         }
//         return `https://api.dicebear.com/6.x/pixel-art/svg?seed=${seed}`;
//     };
//     const selectedUserAvatar = selectedUser ? getAvatarUrl(selectedUser) : null;

//     useEffect(()=>{
//          return ()=>
//             dispatch(setSelectedUser(null))
//     }, [])
//     return (
//         <>
//             {
//                 selectedUser ?(
//                  <div className='min-w-0 w-full max-w-full md:min-w-[550px] flex flex-col'>

//                 <div className='flex flex-row flex-wrap items-center gap-3 rounded-3xl border border-white/10 bg-slate-900/90 p-3 text-white shadow-lg shadow-slate-950/30 mx-2 my-2'>

//                     <div className='relative flex h-14 w-14 shrink-0 items-center justify-center rounded-full border-2 border-white/20 bg-slate-800/80 overflow-hidden sm:h-16 sm:w-16'>
//                         <img src={selectedUserAvatar} alt='profilePhoto' className='h-full w-full rounded-full object-cover' />
//                     </div>

//                     <div className='min-w-0 flex-1'>
//                         <p className='truncate text-base font-bold text-white sm:text-lg'>{selectedUser?.username}</p>
//                     </div>
//                 </div>
//                 <Messages/>
//                 <SendInput/>
//             </div>)
//             :
//             (<div className='min-w-0 w-full flex flex-col items-center justify-center px-4 py-6 text-center'>
//                   <div>
//                      <h1 className='text-3xl font-bold text-white sm:text-4xl'>Hi, {authUser?.username}</h1>
//                   </div>
//                    <h1 className='mt-3 text-xl text-white/80 sm:text-2xl'>Let&apos;s start the conversation.</h1>
//             </div>)
//             }
//         </>
//         // <div className='md : min-w-[550px] flex flex-col'>
           
//         //         <div className='flex flex-row gap-2 items-center rounded-sm p-2 cursor-pointer bg-zinc-800 px-2  text-white mx-2 my-2 mb-2'>

//         //             <div className="avatar online ring ring-green-500 ring-offset-base-100 ring-offset-2">

//         //                 <div className='w-12 rounded-full'>
//         //                     <img src={selectedUser?.profilePicture} alt='profilePhoto'/>
//         //                 </div>
//         //             </div>

//         //             <div className="flex flex-col flex-1">

//         //                 <div className='flex gap-2 flex-1'>
//         //                     <p>{selectedUser?.username}</p>
//         //                 </div>
//         //             </div>
//         //         </div>
//         //         <Messages/>
//         //         <SendInput/>
//         //     </div>
       
//     )
// }
// import React, { useState, useEffect } from 'react'
// import SendInput from './SendInput'
// import Messages from './Messages'
// import Store from '../redux/store'
// import { useSelector, useDispatch } from 'react-redux'
// import { setSelectedUser } from '../redux/UserSlice'

// // Import the WebRTC hook and Call Modal we created earlier
// import { useWebRTC } from '../hooks/useWebRTC'
// import CallModal from './CallModal'

// export default function MesssageContainer() {
//     const dispatch = useDispatch();
//     const { selectedUser, authUser } = useSelector(Store => Store.user);
    
//     // Initialize WebRTC
//     const {
//         callState,
//         localStream,
//         remoteStream,
//         initiateCall,
//         answerCall,
//         rejectCall,
//         endCall,
//         toggleMic,
//         toggleCamera,
//     } = useWebRTC();

//     const getAvatarUrl = (user) => {
//         const seed = encodeURIComponent(user?.username || user?._id || 'user');
//         if (user?.gender?.toLowerCase() === 'male') {
//             return `https://api.dicebear.com/6.x/bottts/svg?seed=male-${seed}`;
//         }
//         if (user?.gender?.toLowerCase() === 'female') {
//             return `https://api.dicebear.com/6.x/bottts/svg?seed=female-${seed}`;
//         }
//         return `https://api.dicebear.com/6.x/pixel-art/svg?seed=${seed}`;
//     };
//     const selectedUserAvatar = selectedUser ? getAvatarUrl(selectedUser) : null;

//     useEffect(() => {
//         return () =>
//             dispatch(setSelectedUser(null))
//     }, [])

//     return (
//         <>
//             {
//                 selectedUser ? (
//                     <div className='min-w-0 w-full max-w-full md:min-w-[550px] flex flex-col relative'>

//                         <div className='flex flex-row flex-wrap items-center gap-3 rounded-3xl border border-white/10 bg-slate-900/90 p-3 text-white shadow-lg shadow-slate-950/30 mx-2 my-2'>

//                             <div className='relative flex h-14 w-14 shrink-0 items-center justify-center rounded-full border-2 border-white/20 bg-slate-800/80 overflow-hidden sm:h-16 sm:w-16'>
//                                 <img src={selectedUserAvatar} alt='profilePhoto' className='h-full w-full rounded-full object-cover' />
//                             </div>

//                             <div className='min-w-0 flex-1'>
//                                 <p className='truncate text-base font-bold text-white sm:text-lg'>{selectedUser?.username}</p>
//                             </div>

//                             {/* ==================== NEW CALL LOGOS ==================== */}
//                             <div className="flex items-center gap-2 ml-auto pr-1">
                                
//                                 {/* Audio Call Button */}
//                                 <button 
//                                     onClick={() => initiateCall(selectedUser?._id, 'audio')}
//                                     className="p-2.5 rounded-full hover:bg-white/10 transition-colors duration-200 group"
//                                     title="Audio Call"
//                                 >
//                                     <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 text-slate-300 group-hover:text-green-400 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
//                                         <path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
//                                     </svg>
//                                 </button>

//                                 {/* Video Call Button */}
//                                 <button 
//                                     onClick={() => initiateCall(selectedUser?._id, 'video')}
//                                     className="p-2.5 rounded-full hover:bg-white/10 transition-colors duration-200 group"
//                                     title="Video Call"
//                                 >
//                                     <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 text-slate-300 group-hover:text-blue-400 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
//                                         <path strokeLinecap="round" strokeLinejoin="round" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
//                                     </svg>
//                                 </button>

//                             </div>
//                             {/* ==================== END CALL LOGOS ==================== */}

//                         </div>
                        
//                         <Messages />
//                         <SendInput />

//                         {/* The Call Modal UI (Ringing/Active call screen) */}
//                         <CallModal 
//                             callState={callState}
//                             localStream={localStream}
//                             remoteStream={remoteStream}
//                             onAnswer={answerCall}
//                             onReject={rejectCall}
//                             onEnd={endCall}
//                             onToggleMic={toggleMic}
//                             onToggleCamera={toggleCamera}
//                         />
//                     </div>)
//                     :
//                     (<div className='min-w-0 w-full flex flex-col items-center justify-center px-4 py-6 text-center'>
//                         <div>
//                             <h1 className='text-3xl font-bold text-white sm:text-4xl'>Hi, {authUser?.username}</h1>
//                         </div>
//                         <h1 className='mt-3 text-xl text-white/80 sm:text-2xl'>Let&apos;s start the conversation.</h1>
//                     </div>)
//             }
//         </>
//     )
// }
// import React, { useState, useEffect } from 'react'
// import SendInput from './SendInput'
// import Messages from './Messages'
// import Store from '../redux/store'
// import { useSelector, useDispatch } from 'react-redux'
// import { setSelectedUser } from '../redux/UserSlice'
// import CallModal from './CallModal'
// import { useWebRTC } from '../hooks/useWebRTC'

// export default function MesssageContainer() {
//     const dispatch = useDispatch();
//     const { selectedUser, authUser } = useSelector(Store => Store.user);
//     const { socket } = useSelector(Store => Store.socket);
    
//     // Typing State
//     const [isTyping, setIsTyping] = useState(false);

//     // WebRTC State
//     const { callState, localStream, remoteStream, initiateCall, answerCall, rejectCall, endCall, toggleMic, toggleCamera } = useWebRTC();

//     // 🔥 NEW: Get the first letter for the avatar
//     const selectedUserInitial = selectedUser?.username?.trim()?.charAt(0)?.toUpperCase() || '?';

//     // Typing Listener
//     useEffect(() => {
//         if (!socket) return;

//         socket.on("typing", ({ from }) => {
//             if (from === selectedUser?._id) {
//                 setIsTyping(true);
//                 setTimeout(() => {
//                     setIsTyping(false);
//                 }, 2000);
//             }
//         });

//         return () => socket.off("typing");
//     }, [socket, selectedUser?._id]);

//     // Cleanup on unmount
//     useEffect(() => {
//         return () => dispatch(setSelectedUser(null))
//     }, [])

//     return (
//         <>
//             {
//                 selectedUser ? (
//                <div className='min-w-0 w-full max-w-full xl:min-w-[550px] flex flex-col h-full overflow-hidden relative'>
                        
//                         {/* Header */}
//                         <div className='flex flex-row flex-wrap items-center gap-3 rounded-3xl border border-white/10 bg-slate-900/90 p-3 text-white shadow-lg shadow-slate-950/30 mx-2 my-2'>
                            
//                             {/* Avatar Container */}
//                             <div className='relative flex h-14 w-14 shrink-0 items-center justify-center rounded-full border-2 border-white/20 bg-slate-800/80 overflow-hidden sm:h-16 sm:w-16'>
                                
//                                 {/* CONDITIONAL RENDERING: Image vs First Letter */}
//                                 {selectedUser?.profilePicture && !selectedUser.profilePicture.includes('iran.liara.run') ? (
//                                     <img 
//                                         src={selectedUser.profilePicture} 
//                                         alt='profilePhoto' 
//                                         className='h-full w-full rounded-full object-cover' 
//                                     />
//                                 ) : (
//                                     <span className="text-2xl font-bold text-white sm:text-3xl">
//                                         {selectedUserInitial}
//                                     </span>
//                                 )}
//                             </div>

//                             <div className='min-w-0 flex-1'>
//                                 <p className='truncate text-base font-bold text-white sm:text-lg'>{selectedUser?.username}</p>
//                                 <p className='text-xs text-green-400 h-4'>
//                                     {isTyping ? "typing..." : ""}
//                                 </p>
//                             </div>

//                             {/* Call Icons */}
//                             <div className="flex items-center gap-2 ml-auto pr-1">
//                                 <button onClick={() => initiateCall(selectedUser?._id, 'audio')} className="p-2.5 rounded-full hover:bg-white/10 transition-colors duration-200 group" title="Audio Call">
//                                     <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 text-slate-300 group-hover:text-green-400 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
//                                 </button>
//                                 <button onClick={() => initiateCall(selectedUser?._id, 'video')} className="p-2.5 rounded-full hover:bg-white/10 transition-colors duration-200 group" title="Video Call">
//                                     <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 text-slate-300 group-hover:text-blue-400 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
//                                 </button>
//                             </div>
//                         </div>
                        
//                         <Messages />
//                         <SendInput />

//                         <CallModal 
//                             callState={callState} 
//                             localStream={localStream} 
//                             remoteStream={remoteStream} 
//                             onAnswer={answerCall} 
//                             onReject={rejectCall} 
//                             onEnd={endCall} 
//                             onToggleMic={toggleMic} 
//                             onToggleCamera={toggleCamera} 
//                         />
//                     </div>
//                 )
//                 :
//                 (
//                     <div className='min-w-0 w-full flex flex-col items-center justify-center px-4 py-6 text-center'>
//                         <div><h1 className='text-3xl font-bold text-white sm:text-4xl'>Hi, {authUser?.username}</h1></div>
//                         <h1 className='mt-3 text-xl text-white/80 sm:text-2xl'>Let&apos;s start the conversation.</h1>
//                     </div>
//                 )
//             }
//         </>
//     )
// }
// import React, { useState, useEffect } from 'react'
// import SendInput from './SendInput'
// import Messages from './Messages'
// import Store from '../redux/store'
// import { useSelector, useDispatch } from 'react-redux'
// import { setSelectedUser } from '../redux/UserSlice'
// import CallModal from './CallModal'
// import { useWebRTC } from '../hooks/useWebRTC'

// // 1. ADD onBack TO PROPS
// export default function MesssageContainer({ onBack }) {
//     const dispatch = useDispatch();
//     const { selectedUser, authUser } = useSelector(Store => Store.user);
//     const { socket } = useSelector(Store => Store.socket);
    
//     const [isTyping, setIsTyping] = useState(false);
//     const [imgError, setImgError] = useState(false);

//     const { callState, localStream, remoteStream, initiateCall, answerCall, rejectCall, endCall, toggleMic, toggleCamera } = useWebRTC();

//     const selectedUserInitial = selectedUser?.username?.trim()?.charAt(0)?.toUpperCase() || '?';

//     useEffect(() => {
//         if (!socket) return;

//         socket.on("typing", ({ from }) => {
//             if (from === selectedUser?._id) {
//                 setIsTyping(true);
//                 setTimeout(() => {
//                     setIsTyping(false);
//                 }, 2000);
//             }
//         });

//         return () => socket.off("typing");
//     }, [socket, selectedUser?._id]);

//     useEffect(() => {
//         return () => dispatch(setSelectedUser(null))
//     }, [])

//     return (
//         <>
//             {
//                 selectedUser ? (
//                     <div className='min-w-0 w-full max-w-full xl:min-w-[550px] flex flex-col h-full overflow-hidden relative'>
                        
//                         {/* HEADER */}
//                         <div className='flex flex-row flex-wrap items-center gap-3 rounded-3xl border border-white/10 bg-slate-900/90 p-3 text-white shadow-lg shadow-slate-950/30 mx-2 my-2'>
                            
//                             {/* ==========================================
//                             📱 BACK BUTTON (HIDDEN ON DESKTOP)
//                             ========================================== */}
//                             <button 
//                                 onClick={onBack} 
//                                 className="p-2 rounded-full hover:bg-white/10 transition-colors md:hidden" 
//                                 title="Go back"
//                             >
//                                 <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
//                                     <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
//                                 </svg>
//                             </button>

//                             {/* AVATAR */}
//                             <div className='relative flex h-14 w-14 shrink-0 items-center justify-center rounded-full border-2 border-white/20 bg-slate-800/80 overflow-hidden sm:h-16 sm:w-16'>
//                                 {selectedUser?.profilePicture && !selectedUser.profilePicture.includes('iran.liara.run') && !imgError ? (
//                                     <img 
//                                         src={selectedUser.profilePicture} 
//                                         alt='profilePhoto' 
//                                         className='h-full w-full rounded-full object-cover' 
//                                         onError={() => setImgError(true)} 
//                                     />
//                                 ) : (
//                                     <div className="w-full h-full flex items-center justify-center bg-slate-700 rounded-full">
//                                         <span className="text-2xl font-bold text-white sm:text-3xl">
//                                             {selectedUserInitial}
//                                         </span>
//                                     </div>
//                                 )}
//                             </div>

//                             {/* NAME & TYPING */}
//                             <div className='min-w-0 flex-1'>
//                                 <p className='truncate text-base font-bold text-white sm:text-lg'>{selectedUser?.username}</p>
//                                 <p className='text-xs text-green-400 h-4'>
//                                     {isTyping ? "typing..." : ""}
//                                 </p>
//                             </div>

//                             {/* CALL ICONS */}
//                             <div className="flex items-center gap-2 ml-auto pr-1">
//                                 <button onClick={() => initiateCall(selectedUser?._id, 'audio')} className="p-2.5 rounded-full hover:bg-white/10 transition-colors duration-200 group" title="Audio Call">
//                                     <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 text-slate-300 group-hover:text-green-400 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
//                                 </button>
//                                 <button onClick={() => initiateCall(selectedUser?._id, 'video')} className="p-2.5 rounded-full hover:bg-white/10 transition-colors duration-200 group" title="Video Call">
//                                     <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 text-slate-300 group-hover:text-blue-400 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
//                                 </button>
//                             </div>
//                         </div>
                        
//                         <Messages />
//                         <SendInput />

//                         <CallModal 
//                             callState={callState} 
//                             localStream={localStream} 
//                             remoteStream={remoteStream} 
//                             onAnswer={answerCall} 
//                             onReject={rejectCall} 
//                             onEnd={endCall} 
//                             onToggleMic={toggleMic} 
//                             onToggleCamera={toggleCamera} 
//                         />
//                     </div>
//                 )
//                 :
//                 (
//                     <div className='min-w-0 w-full flex flex-col items-center justify-center px-4 py-6 text-center'>
//                         <div><h1 className='text-3xl font-bold text-white sm:text-4xl'>Hi, {authUser?.username}</h1></div>
//                         <h1 className='mt-3 text-xl text-white/80 sm:text-2xl'>Let&apos;s start the conversation.</h1>
//                     </div>
//                 )
//             }
//         </>
//     )
// }
import React from 'react';
import { useSelector } from 'react-redux';
import Messages from './Messages'; 
import SendInput from './SendInput'; 

const MesssageContainer = ({ onBack, onInitiateCall }) => {
  const { selectedUser, authUser } = useSelector(store => store.user);

  return (
    <div className='flex flex-col h-full w-full relative'>
      
      {/* CHAT HEADER */}
      <div className='flex items-center justify-between px-3 sm:px-4 py-3 bg-slate-800/50 border-b border-white/10'>
        
        <div className='flex items-center gap-3 min-w-0 flex-1'>
          {/* Back Button (Mobile Only) */}
          <button 
            onClick={onBack} 
            className='md:hidden text-white text-2xl hover:bg-white/10 p-1 rounded-full active:scale-95 transition-transform shrink-0'
          >
            <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7"/></svg>
          </button>
          
          <div className='flex items-center gap-3 min-w-0'>
             <span className='text-white font-semibold text-base sm:text-lg truncate'>{selectedUser?.username}</span>
          </div>
        </div>

        {/* CALL ICONS (Always visible on all screens) */}
        <div className='flex items-center gap-1 sm:gap-2 shrink-0 ml-2'>
           
           {/* Audio Call Icon */}
           <button 
             onClick={() => onInitiateCall(selectedUser?._id, 'audio')} 
             className='w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-full hover:bg-white/10 text-slate-300 hover:text-white active:scale-95 transition-all'
             title="Audio Call"
           >
             <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
               <path d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56a.977.977 0 0 0-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02-.37-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 3 3 3.24 3 3.99 3 13.28 10.73 21 20.01 21c.71 0 .99-.63.99-1.18v-3.45c0-.54-.45-.99-.99-.99z"/>
             </svg>
           </button>

           {/* Video Call Icon */}
           <button 
             onClick={() => onInitiateCall(selectedUser?._id, 'video')} 
             className='w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-full hover:bg-white/10 text-slate-300 hover:text-white active:scale-95 transition-all'
             title="Video Call"
           >
             <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
               <path d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z"/>
             </svg>
           </button>

        </div>
      </div>

      {/* MESSAGES AREA */}
      <div className='flex-1 overflow-y-auto px-4 py-2'>
        <Messages />
      </div>

      {/* INPUT AREA */}
      <div className='px-4 pb-4 pt-2'>
        <SendInput />
      </div>

    </div>
  );
};

export default MesssageContainer;