// // import React from 'react'
// // import MesssageContainer from './MesssageContainer';
// // import SiedeBar from './SiedeBar';
// // export default function Homepage() {
// //   return (
// //     <div className='flex sm:h-[450px] md:h-[450px] rounded-lg overflow-hidden bg-white/30 backdrop-blur-lg'>
// //   <SiedeBar />
// //   <MesssageContainer />
// // </div>

// //   )
// // }
// // import React, { useState } from 'react';
// // import MesssageContainer from './MesssageContainer';
// // import SiedeBar from './SiedeBar';
// // import { useSelector, useDispatch } from 'react-redux';
// // import { setSelectedUser } from '../redux/UserSlice';

// // export default function Homepage() {
// //   const dispatch = useDispatch();
// //   const { selectedUser } = useSelector(store => store.user);
  
// //   const [mobileView, setMobileView] = useState('sidebar');

// //   const handleSelectUser = (user) => {
// //     dispatch(setSelectedUser(user));
// //     setMobileView('chat');
// //   };

// //   const handleBack = () => {
// //     setMobileView('sidebar');
// //     dispatch(setSelectedUser(null));
// //   };

// //   return (
// //     <div className='flex h-screen w-full md:h-[450px] rounded-lg overflow-clip bg-white/30 backdrop-blur-lg relative'>
      
// //       {/* SIDEBAR - Added overflow-hidden */}
// //       <div className={`${mobileView === 'chat' ? 'hidden' : 'flex'} w-full md:w-[350px] md:flex flex-col border-r border-white/10 overflow-hidden`}>
// //         <SiedeBar onSelectUser={handleSelectUser} />
// //       </div>

// //       {/* CHAT AREA - Added overflow-hidden */}
// //       <div className={`${mobileView !== 'chat' ? 'hidden' : 'flex'} flex-1 flex-col overflow-hidden`}>
// //         {selectedUser ? (
// //           <MesssageContainer onBack={handleBack} />
// //         ) : (
// //           <div className='flex-1 flex flex-col items-center justify-center px-4 py-6 text-center'>
// //             <div><h1 className='text-3xl font-bold text-white sm:text-4xl'>Hi, User</h1></div>
// //             <h1 className='mt-3 text-xl text-white/80 sm:text-2xl'>Select a user to start chatting.</h1>
// //           </div>
// //         )}
// //       </div>

// //     </div>
// //   )
// // }
// // import React, { useState, useEffect } from 'react'
// // import MesssageContainer from './MesssageContainer';
// // import SiedeBar from './SiedeBar';
// // import { useSelector, useDispatch } from 'react-redux';
// // import { setSelectedUser } from '../redux/UserSlice';

// // export default function Homepage() {
// //   const dispatch = useDispatch();
// //   const { selectedUser, authUser } = useSelector(store => store.user);
  
// //   const [mobileView, setMobileView] = useState('sidebar');

// //   // 🔥 CRITICAL FIX: Clear the old chat instantly when Homepage loads
// //   useEffect(() => {
// //     dispatch(setSelectedUser(null));
// //   }, [dispatch]); 

// //   const handleSelectUser = (user) => {
// //     dispatch(setSelectedUser(user));
// //     setMobileView('chat');
// //   };

// //   const handleBack = () => {
// //     setMobileView('sidebar');
// //     dispatch(setSelectedUser(null));
// //   };

// //   return (
// //     <div className='flex w-full md:h-[450px] rounded-lg overflow-clip bg-white/30 backdrop-blur-lg relative h-full'>
      
// //       {/* SIDEBAR */}
// //       <div className={`${mobileView === 'chat' ? 'hidden' : 'flex'} w-full md:w-[350px] md:flex flex-col border-r border-white/10 overflow-clip`}>
// //         <SiedeBar onSelectUser={handleSelectUser} />
// //       </div>

// //       {/* MAIN CHAT AREA */}
// //       <div className={`${mobileView !== 'chat' ? 'hidden' : 'flex'} flex-1 flex-col overflow-clip`}>
// //         {selectedUser ? (
// //           <MesssageContainer onBack={handleBack} />
// //         ) : (
// //           <div className='min-w-0 w-full h-full flex flex-col items-center justify-center px-4 py-6 text-center bg-slate-800/50 rounded-lg m-2'>
// //              <div className="text-6xl mb-4">💬</div>
// //              <div>
// //                 <h1 className='text-3xl font-bold text-white sm:text-4xl'>Hi, {authUser?.username}</h1>
// //              </div>
// //              <h1 className='mt-3 text-xl text-white/80 sm:text-2xl'>Let&apos;s start the conversation.</h1>
// //           </div>
// //         )}
// //       </div>

// //     </div>
// //   )
// // }
// // 
// import React, { useState, useEffect } from 'react'
// import MesssageContainer from './MesssageContainer'
// import SiedeBar from './SiedeBar'
// import { useSelector, useDispatch } from 'react-redux'
// import { setSelectedUser } from '../redux/UserSlice'

// export default function Homepage() {
//   const dispatch = useDispatch();
//   const { selectedUser, authUser } = useSelector(store => store.user);
  
//   const [mobileView, setMobileView] = useState('sidebar');

//   useEffect(() => {
//     dispatch(setSelectedUser(null));
//   }, [dispatch]); 

//   const handleSelectUser = (user) => {
//     dispatch(setSelectedUser(user));
//     setMobileView('chat');
//   };

//   const handleBack = () => {
//     setMobileView('sidebar');
//     dispatch(setSelectedUser(null));
//   };

//   return (
//     <div className='flex w-full md:h-[450px] rounded-lg overflow-clip bg-white/30 backdrop-blur-lg relative h-full'>
      
//       {/* SIDEBAR */}
//       <div className={`${mobileView === 'chat' ? 'hidden' : 'flex'} w-full md:w-[350px] md:flex flex-col border-r border-white/10 overflow-clip`}>
//         <SiedeBar onSelectUser={handleSelectUser} />
//       </div>

//       {/* RIGHT SIDE CONTAINER */}
//       <div className={`${mobileView !== 'chat' ? 'hidden' : 'flex'} flex-1 flex-col overflow-clip`}>
//         {selectedUser ? (
//           <MesssageContainer onBack={handleBack} />
//         ) : (
//           // 🔥 MIN-H-[200PX] PREVENTS IT FROM COLLAPSING TO 0PX!
//           // SOLID BG-COLOR SO YOU CAN EASILY SEE IT
//           <div className='min-h-[200px] w-full flex flex-col items-center justify-center px-4 py-6 text-center bg-slate-700 rounded-lg mx-2'>
//              <div className="text-6xl mb-4">💬</div>
//              <div>
//                 <h1 className='text-3xl font-bold text-white sm:text-4xl'>Hi, {authUser?.username}</h1>
//              </div>
//              <h1 className='mt-3 text-xl text-slate-300 sm:text-2xl'>Let&apos;s start the conversation.</h1>
//           </div>
//         )}
//       </div>

//     </div>
//   )
// }
// import React, { useState, useEffect } from 'react'
// import MesssageContainer from './MesssageContainer'
// import SiedeBar from './SiedeBar'
// import { useSelector, useDispatch } from 'react-redux'
// import { setSelectedUser } from '../redux/UserSlice'

// export default function Homepage() {
//   const dispatch = useDispatch();
//   const { selectedUser, authUser } = useSelector(store => store.user);
  
//   const [mobileView, setMobileView] = useState('sidebar');

//   useEffect(() => {
//     dispatch(setSelectedUser(null));
//   }, [dispatch]); 

//   const handleSelectUser = (user) => {
//     dispatch(setSelectedUser(user));
//     setMobileView('chat');
//   };

//   const handleBack = () => {
//     setMobileView('sidebar');
//     dispatch(setSelectedUser(null));
//   };

//   return (
//     <div className='flex w-full md:h-[450px] rounded-lg overflow-clip bg-white/30 backdrop-blur-lg relative h-full'>
      
//       {/* SIDEBAR */}
//       <div className={`${mobileView === 'chat' ? 'hidden' : 'flex'} w-full md:w-[350px] md:flex flex-col border-r border-white/10 overflow-clip`}>
//         <SiedeBar onSelectUser={handleSelectUser} />
//       </div>

//       {/* RIGHT SIDE CONTAINER */}
//       {/* ✅ FIX: Added 'md:flex' so "Hi User" shows on Desktop when no chat is selected */}
//       <div className={`${mobileView !== 'chat' ? 'hidden md:flex' : 'flex'} flex-1 flex-col overflow-clip`}>
//         {selectedUser ? (
//           <MesssageContainer onBack={handleBack} />
//         ) : (
//           <div className='min-h-[200px] w-full flex flex-col items-center justify-center px-4 py-6 text-center bg-slate-700 rounded-lg mx-2'>
//              <div className="text-6xl mb-4">💬</div>
//              <div>
//                 <h1 className='text-3xl font-bold text-white sm:text-4xl'>Hi, {authUser?.username}</h1>
//              </div>
//              <h1 className='mt-3 text-xl text-slate-300 sm:text-2xl'>Let&apos;s start the conversation.</h1>
//           </div>
//         )}
//       </div>

//     </div>
//   )
// }

// import React, { useState, useEffect } from 'react'
// import MesssageContainer from './MesssageContainer'
// import SiedeBar from './SiedeBar'
// import CallModal from './CallModal' // <--- 1. IMPORT CALL MODAL
// import { useWebRTC } from '../hooks/useWebRTC' // <--- 2. IMPORT WEBRTC HOOK
// import { useSelector, useDispatch } from 'react-redux'
// import { setSelectedUser } from '../redux/UserSlice'

// export default function Homepage() {
//   const dispatch = useDispatch();
//   const { selectedUser, authUser } = useSelector(store => store.user);
  
//   const [mobileView, setMobileView] = useState('sidebar');

//   // 3. INITIALIZE WEBRTC HERE SO IT NEVER UNMOUNTS WHEN SWITCHING VIEWS
//   const {
//     callState,
//     localStream,
//     remoteStream,
//     initiateCall,
//     answerCall,
//     rejectCall,
//     endCall,
//     toggleMic,
//     toggleCamera
//   } = useWebRTC();

//   useEffect(() => {
//     dispatch(setSelectedUser(null));
//   }, [dispatch]); 

//   const handleSelectUser = (user) => {
//     dispatch(setSelectedUser(user));
//     setMobileView('chat');
//   };

//   const handleBack = () => {
//     setMobileView('sidebar');
//     dispatch(setSelectedUser(null));
//   };

//   return (
//     <div className='flex w-full md:h-[450px] rounded-lg overflow-clip bg-white/30 backdrop-blur-lg relative h-full'>
      
//       {/* SIDEBAR */}
//       <div className={`${mobileView === 'chat' ? 'hidden' : 'flex'} w-full md:w-[350px] md:flex flex-col border-r border-white/10 overflow-clip`}>
//         <SiedeBar onSelectUser={handleSelectUser} />
//       </div>

//       {/* RIGHT SIDE CONTAINER */}
//       <div className={`${mobileView !== 'chat' ? 'hidden md:flex' : 'flex'} flex-1 flex-col overflow-clip`}>
//         {selectedUser ? (
//           // 4. PASS onInitiateCall DOWN TO MESSAGE CONTAINER
//           <MesssageContainer 
//             onBack={handleBack} 
//             onInitiateCall={initiateCall} 
//           />
//         ) : (
//           <div className='min-h-[200px] w-full flex flex-col items-center justify-center px-4 py-6 text-center bg-slate-700 rounded-lg mx-2'>
//              <div className="text-6xl mb-4">💬</div>
//              <div>
//                 <h1 className='text-3xl font-bold text-white sm:text-4xl'>Hi, {authUser?.username}</h1>
//              </div>
//              <h1 className='mt-3 text-xl text-slate-300 sm:text-2xl'>Let&apos;s start the conversation.</h1>
//           </div>
//         )}
//       </div>

//       {/* 5. ADD CALL MODAL HERE */}
//       {/* Because CallModal uses a Portal, it will show full-screen regardless of this overflow-clip container */}
//       <CallModal 
//         callState={callState}
//         localStream={localStream}
//         remoteStream={remoteStream}
//         onAnswer={answerCall}
//         onReject={rejectCall}
//         onEnd={endCall}
//         onToggleMic={toggleMic}
//         onToggleCamera={toggleCamera}
//       />

//     </div>
//   )
// }
// import React, { useState, useEffect } from 'react'
// import MesssageContainer from './MesssageContainer'
// import SiedeBar from './SiedeBar'
// import CallModal from './CallModal' 
// import { useWebRTC } from '../hooks/useWebRTC' 
// import { useSelector, useDispatch } from 'react-redux'
// import { setSelectedUser } from '../redux/UserSlice'
// import { resetUnread } from '../redux/UserSlice' // <--- 1. ADD THIS IMPORT

// export default function Homepage() {
//   const dispatch = useDispatch();
//   const { selectedUser, authUser } = useSelector(store => store.user);
  
//   const [mobileView, setMobileView] = useState('sidebar');

//   const {
//     callState,
//     localStream,
//     remoteStream,
//     initiateCall,
//     answerCall,
//     rejectCall,
//     endCall,
//     toggleMic,
//     toggleCamera
//   } = useWebRTC();

//   useEffect(() => {
//     dispatch(setSelectedUser(null));
//   }, [dispatch]); 

//   const handleSelectUser = (user) => {
//     dispatch(resetUnread(user._id)); // <--- 2. ADD THIS LINE: Removes the red dot immediately!
//     dispatch(setSelectedUser(user));
//     setMobileView('chat');
//   };

//   const handleBack = () => {
//     setMobileView('sidebar');
//     dispatch(setSelectedUser(null));
//   };

//   return (
//     <div className='flex w-full md:h-[450px] rounded-lg overflow-clip bg-white/30 backdrop-blur-lg relative h-full'>
      
//       {/* SIDEBAR */}
//       <div className={`${mobileView === 'chat' ? 'hidden' : 'flex'} w-full md:w-[350px] md:flex flex-col border-r border-white/10 overflow-clip`}>
//         <SiedeBar onSelectUser={handleSelectUser} />
//       </div>

//       {/* RIGHT SIDE CONTAINER */}
//       <div className={`${mobileView !== 'chat' ? 'hidden md:flex' : 'flex'} flex-1 flex-col overflow-clip`}>
//         {selectedUser ? (
//           <MesssageContainer 
//             onBack={handleBack} 
//             onInitiateCall={initiateCall} 
//           />
//         ) : (
//           <div className='min-h-[200px] w-full flex flex-col items-center justify-center px-4 py-6 text-center bg-slate-700 rounded-lg mx-2'>
//              <div className="text-6xl mb-4">💬</div>
//              <div>
//                 <h1 className='text-3xl font-bold text-white sm:text-4xl'>Hi, {authUser?.username}</h1>
//              </div>
//              <h1 className='mt-3 text-xl text-slate-300 sm:text-2xl'>Let&apos;s start the conversation.</h1>
//           </div>
//         )}
//       </div>

//       <CallModal 
//         callState={callState}
//         localStream={localStream}
//         remoteStream={remoteStream}
//         onAnswer={answerCall}
//         onReject={rejectCall}
//         onEnd={endCall}
//         onToggleMic={toggleMic}
//         onToggleCamera={toggleCamera}
//       />

//     </div>
//   )
// }
// import React, { useState, useEffect, useRef } from 'react' // <--- ADD useRef
// import MesssageContainer from './MesssageContainer'
// import SiedeBar from './SiedeBar'
// import CallModal from './CallModal' 
// import { useWebRTC } from '../hooks/useWebRTC' 
// import { useSelector, useDispatch } from 'react-redux'
// import { setSelectedUser, resetUnread } from '../redux/UserSlice' // Combined imports

// export default function Homepage() {
//   const dispatch = useDispatch();
//   const { selectedUser, authUser, otherUsers } = useSelector(store => store.user); // <--- ADD otherUsers
  
//   const [mobileView, setMobileView] = useState('sidebar');
//   const hasAutoSelected = useRef(false); // <--- ADD THIS MEMORY FLAG

//   const {
//     callState,
//     localStream,
//     remoteStream,
//     initiateCall,
//     answerCall,
//     rejectCall,
//     endCall,
//     toggleMic,
//     toggleCamera
//   } = useWebRTC();

//   // ==========================================
//   // 🔥 AUTO-SELECT FIRST USER (SAFE FOR MOBILE)
//   // ==========================================
//   useEffect(() => {
//     // If we haven't auto-selected yet, AND the user list exists, AND no chat is open...
//     if (!hasAutoSelected.current && otherUsers?.length > 0 && !selectedUser) {
//       const firstUser = otherUsers[0];
//       dispatch(resetUnread(firstUser._id)); 
//       dispatch(setSelectedUser(firstUser)); 
//       setMobileView('chat'); 
      
//       hasAutoSelected.current = true; // <--- LOCK IT so it never runs again
//     }
//   }, [otherUsers, selectedUser, dispatch]); 

//   const handleSelectUser = (user) => {
//     dispatch(resetUnread(user._id));
//     dispatch(setSelectedUser(user));
//     setMobileView('chat');
//   };

//   const handleBack = () => {
//     // This safely sets it to null. Because hasAutoSelected is TRUE, 
//     // the useEffect above will IGNORE it, keeping you on the sidebar!
//     setMobileView('sidebar');
//     dispatch(setSelectedUser(null));
//   };

//   return (
//     <div className='flex w-full md:h-[450px] rounded-lg overflow-clip bg-white/30 backdrop-blur-lg relative h-full'>
      
//       {/* SIDEBAR */}
//       <div className={`${mobileView === 'chat' ? 'hidden' : 'flex'} w-full md:w-[350px] md:flex flex-col border-r border-white/10 overflow-clip`}>
//         <SiedeBar onSelectUser={handleSelectUser} />
//       </div>

//       {/* RIGHT SIDE CONTAINER */}
//       <div className={`${mobileView !== 'chat' ? 'hidden md:flex' : 'flex'} flex-1 flex-col overflow-clip`}>
//         {selectedUser ? (
//           <MesssageContainer 
//             onBack={handleBack} 
//             onInitiateCall={initiateCall} 
//           />
//         ) : (
//           <div className='min-h-[200px] w-full flex flex-col items-center justify-center px-4 py-6 text-center bg-slate-700 rounded-lg mx-2'>
//              <div className="text-6xl mb-4">💬</div>
//              <div>
//                 <h1 className='text-3xl font-bold text-white sm:text-4xl'>Hi, {authUser?.username}</h1>
//              </div>
//              <h1 className='mt-3 text-xl text-slate-300 sm:text-2xl'>Let&apos;s start the conversation.</h1>
//           </div>
//         )}
//       </div>

//       <CallModal 
//         callState={callState}
//         localStream={localStream}
//         remoteStream={remoteStream}
//         onAnswer={answerCall}
//         onReject={rejectCall}
//         onEnd={endCall}
//         onToggleMic={toggleMic}
//         onToggleCamera={toggleCamera}
//       />

//     </div>
//   )
// }
import React, { useState, useEffect, useRef } from 'react'
import MesssageContainer from './MesssageContainer'
import SiedeBar from './SiedeBar'
import CallModal from './CallModal' 
import { useWebRTC } from '../hooks/useWebRTC' 
import useGetRealTimeMessage from '../hooks/usesGetRealTimeMessage' // <--- ADD THIS IMPORT
import { useSelector, useDispatch } from 'react-redux'
import { setSelectedUser, resetUnread } from '../redux/UserSlice'

export default function Homepage() {
  const dispatch = useDispatch();
  const { selectedUser, authUser, otherUsers } = useSelector(store => store.user);
  
  const [mobileView, setMobileView] = useState('sidebar');
  const hasAutoSelected = useRef(false);

  const {
    callState,
    localStream,
    remoteStream,
    initiateCall,
    answerCall,
    rejectCall,
    endCall,
    toggleMic,
    toggleCamera
  } = useWebRTC();

  // <--- ADD THIS HOOK CALL HERE!
  // Now it runs 24/7 as long as Homepage is mounted, even if MesssageContainer is hidden
  useGetRealTimeMessage(selectedUser);

  // ==========================================
  // AUTO-SELECT FIRST USER (SAFE FOR MOBILE)
  // ==========================================
  useEffect(() => {
    if (!hasAutoSelected.current && otherUsers?.length > 0 && !selectedUser) {
      const firstUser = otherUsers[0];
      dispatch(resetUnread(firstUser._id)); 
      dispatch(setSelectedUser(firstUser)); 
      setMobileView('chat'); 
      hasAutoSelected.current = true;
    }
  }, [otherUsers, selectedUser, dispatch]); 

  const handleSelectUser = (user) => {
    dispatch(resetUnread(user._id));
    dispatch(setSelectedUser(user));
    setMobileView('chat');
  };

  const handleBack = () => {
    setMobileView('sidebar');
    dispatch(setSelectedUser(null));
  };

  return (
    <div className='flex w-full md:h-[450px] rounded-lg overflow-clip bg-white/30 backdrop-blur-lg relative h-full'>
      
      {/* SIDEBAR */}
      <div className={`${mobileView === 'chat' ? 'hidden' : 'flex'} w-full md:w-[350px] md:flex flex-col border-r border-white/10 overflow-clip`}>
        <SiedeBar onSelectUser={handleSelectUser} />
      </div>

      {/* RIGHT SIDE CONTAINER */}
      <div className={`${mobileView !== 'chat' ? 'hidden md:flex' : 'flex'} flex-1 flex-col overflow-clip`}>
        {selectedUser ? (
          <MesssageContainer 
            onBack={handleBack} 
            onInitiateCall={initiateCall} 
          />
        ) : (
          <div className='min-h-[200px] w-full flex flex-col items-center justify-center px-4 py-6 text-center bg-slate-700 rounded-lg mx-2'>
             <div className="text-6xl mb-4">💬</div>
             <div>
                <h1 className='text-3xl font-bold text-white sm:text-4xl'>Hi, {authUser?.username}</h1>
             </div>
             <h1 className='mt-3 text-xl text-slate-300 sm:text-2xl'>Let&apos;s start the conversation.</h1>
          </div>
        )}
      </div>

      <CallModal 
        callState={callState}
        localStream={localStream}
        remoteStream={remoteStream}
        onAnswer={answerCall}
        onReject={rejectCall}
        onEnd={endCall}
        onToggleMic={toggleMic}
        onToggleCamera={toggleCamera}
      />

    </div>
  )
}