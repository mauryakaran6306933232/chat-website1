
// import React, { useEffect, useRef } from 'react'
// import Store from '../redux/store';
// import { useSelector } from 'react-redux';

// export default function Message({ key, message }) {
//     const scroll = useRef();
//     const { authUser, selectedUser } = useSelector(Store => Store.user)

//     useEffect(() => {
//         scroll?.current?.scrollIntoView({ behavior: "smooth" })
//     }, [message])

//     const senderName = message?.senderId === authUser?._id ? authUser?.username : selectedUser?.username;
//     const senderInitial = senderName?.trim()?.charAt(0)?.toUpperCase() || '?';

//     return (
//         <div>
//             <div ref={scroll} className={`chat ${authUser?._id === message?.senderId ? 'chat-end' : 'chat-start'}`}>
//                 <div className="chat-image">
//                     <div className={`flex h-10 w-10 items-center justify-center rounded-full border-2 ${authUser?._id === message?.senderId ? 'border-cyan-400 bg-cyan-500/15 text-cyan-400' : 'border-violet-400 bg-violet-500/15 text-violet-400'} sm:h-12 sm:w-12 md:h-14 md:w-14`}>
//                         <span className="leading-none text-base font-bold sm:text-lg">{senderInitial}</span>
//                     </div>
//                 </div>
//                 <div className="chat-header">
//                     <time className="text-xs font-bold opacity-50 text-black">12:45</time>
//                 </div>
//                 <div className={`chat-bubble max-w-[80vw] sm:max-w-[70vw] md:max-w-[60vw] ${authUser?._id === message?.senderId ? 'bg-cyan-500 text-slate-900' : 'bg-slate-800 text-white'}`}>
//                     {message?.message}
//                 </div>
//             </div>
//         </div>
//     )
// }
// import React, { useEffect, useRef } from 'react'
// import Store from '../redux/store';
// import { useSelector } from 'react-redux';

// export default function Message({ key, message }) {
//     const scroll = useRef();
//     const { authUser, selectedUser } = useSelector(Store => Store.user)

//     useEffect(() => {
//         scroll?.current?.scrollIntoView({ behavior: "smooth" })
//     }, [message])

//     const senderName = message?.senderId === authUser?._id ? authUser?.username : selectedUser?.username;
//     const senderInitial = senderName?.trim()?.charAt(0)?.toUpperCase() || '?';

//     return (
//         <div>
//             <div ref={scroll} className={`chat ${authUser?._id === message?.senderId ? 'chat-end' : 'chat-start'}`}>
//                 <div className="chat-image">
//                     <div className={`flex h-10 w-10 items-center justify-center rounded-full border-2 ${authUser?._id === message?.senderId ? 'border-cyan-400 bg-cyan-500/15 text-cyan-400' : 'border-violet-400 bg-violet-500/15 text-violet-400'} sm:h-12 sm:w-12 md:h-14 md:w-14`}>
//                         <span className="leading-none text-base font-bold sm:text-lg">{senderInitial}</span>
//                     </div>
//                 </div>
//                 <div className="chat-header">
//                     {/* Displaying real time instead of hardcoded 12:45 */}
//                     <time className="text-xs font-bold opacity-50 text-black">
//                         {new Date(message?.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
//                     </time>
//                 </div>

//                 <div className={`chat-bubble max-w-[80vw] sm:max-w-[70vw] md:max-w-[60vw] break-words ${authUser?._id === message?.senderId ? 'bg-cyan-500 text-slate-900' : 'bg-slate-800 text-white'}`}>

//                     {/* 1. RENDER TEXT (if exists) */}
//                     {message?.message && <p>{message?.message}</p>}

//                     {/* 2. RENDER IMAGE (if exists) */}
//                     {message?.fileUrl && message?.fileType === "image" && (
//                         <img
//                             src={message?.fileUrl}
//                             alt="sent"
//                             className="rounded-lg max-w-full mt-1 cursor-pointer max-h-[300px] object-cover"
//                             onClick={() => window.open(message?.fileUrl, "_blank")} // Click to open full screen
//                         />
//                     )}

//                     {/* 3. RENDER VIDEO (if exists) */}
//                     {message?.fileUrl && message?.fileType === "video" && (
//                         <video
//                             controls
//                             className="rounded-lg max-w-full mt-1 max-h-[300px]"
//                             src={message?.fileUrl}
//                         />
//                     )}


//                                        {/* 4. RENDER PDF / OTHER FILES (if exists) */}
//                     {message?.fileUrl && (message?.fileType === "file" || message?.fileType === "pdf") && (
//                         <a 
//                             href={message?.fileUrl} 
//                             className="flex items-center gap-2 underline text-sm mt-1 font-semibold"
//                             style={{ color: authUser?._id === message?.senderId ? '#1e293b' : '#93c5fd' }}
//                             download // <--- THIS MAGIC WORD tells Brave: "Don't open a new tab, just download it safely"
//                         >
//                             📄 Download File
//                         </a>
//                     )}

//                 </div>
//             </div>
//         </div>
//     )
// }
import React, { useEffect, useRef, useState } from 'react'
import Store from '../redux/store';
import { useSelector, useDispatch } from 'react-redux';
import { setMessageSlice } from '../redux/messageSlice';
import { setReplySlice } from '../redux/replySlice'; // <--- ADDED THIS IMPORT
import axios from 'axios'; 
import toast from 'react-hot-toast';

export default function Message({ message }) {
    const scroll = useRef();
    const { authUser, selectedUser } = useSelector(Store => Store.user);
    const { message: allMessages } = useSelector(Store => Store.message);
    const dispatch = useDispatch();
    
    const [showActions, setShowActions] = useState(false); // Renamed to showActions

    useEffect(() => {
        scroll?.current?.scrollIntoView({ behavior: "smooth" })
    }, [message])

    const senderName = message?.senderId === authUser?._id ? authUser?.username : selectedUser?.username;
    const senderInitial = senderName?.trim()?.charAt(0)?.toUpperCase() || '?';

    const handleDelete = async () => {
        try {
            const res = await axios.delete(`http://localhost:8001/test/delete-message/${message?._id}`, {
                withCredentials: true
            });
            if (res.data.success) {
                const updatedMessages = allMessages.map(msg => 
                    msg._id === message._id 
                    ? { ...msg, message: "This message was deleted", fileUrl: "", fileType: "", deletedForEveryone: true }
                    : msg
                );
                dispatch(setMessageSlice(updatedMessages));
                toast.success("Message deleted");
            }
        } catch (error) {
            toast.error(error.response?.data?.message || "Failed to delete");
        }
    };

    // If message is deleted, render simple text
    if (message?.deletedForEveryone) {
        return (
            <div>
                <div ref={scroll} className={`chat ${authUser?._id === message?.senderId ? 'chat-end' : 'chat-start'}`}>
                    <div className={`chat-bubble max-w-[80vw] sm:max-w-[70vw] md:max-w-[60vw] ${authUser?._id === message?.senderId ? 'bg-gray-500/50 text-gray-300 italic' : 'bg-slate-800/50 text-gray-400 italic'}`}>
                        <p className="text-sm">This message was deleted</p>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <div 
            // FIXED: Show actions for BOTH sender and receiver (so receiver can reply)
            onMouseEnter={() => setShowActions(true)}
            onMouseLeave={() => setShowActions(false)}
        >
            <div ref={scroll} className={`chat ${authUser?._id === message?.senderId ? 'chat-end' : 'chat-start'}`}>
                <div className="chat-image">
                    <div className={`flex h-10 w-10 items-center justify-center rounded-full border-2 ${authUser?._id === message?.senderId ? 'border-cyan-400 bg-cyan-500/15 text-cyan-400' : 'border-violet-400 bg-violet-500/15 text-violet-400'} sm:h-12 sm:w-12 md:h-14 md:w-14`}>
                        <span className="leading-none text-base font-bold sm:text-lg">{senderInitial}</span>
                    </div>
                </div>
                
                {/* HEADER WITH BLUE TICKS */}
                <div className="chat-header flex items-center gap-1">
                    <time className="text-xs font-bold opacity-50 text-black">
                        {new Date(message?.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </time>
                    
                    {authUser?._id === message?.senderId && (
                        <span className="text-xs">
                            {message?.readBy?.includes(message?.receiverId) ? (
                                <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M1 13l4 4L15 7" />
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M7 13l4 4L21 7" />
                                </svg>
                            ) : (
                                <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M1 13l4 4L15 7" />
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M7 13l4 4L21 7" />
                                </svg>
                            )}
                        </span>
                    )}
                </div>
                
                <div className={`chat-bubble max-w-[80vw] sm:max-w-[70vw] md:max-w-[60vw] break-words relative group ${authUser?._id === message?.senderId ? 'bg-cyan-500 text-slate-900' : 'bg-slate-800 text-white'}`}>
                    
                    {/* CLEANED UP ACTION BUTTONS (Reply + Delete) */}
                    {showActions && (
                        <div className="absolute -top-8 right-0 flex gap-2 shadow-lg z-10">
                            {/* REPLY BUTTON */}
                            <button 
                                onClick={() => {
                                    const replyData = {
                                        messageId: message._id,
                                        text: message.message || (message.fileType ? "📎 File" : ""),
                                        username: message?.senderId === authUser?._id ? "You" : selectedUser?.username
                                    };
                                    dispatch(setReplySlice(replyData));
                                }}
                                className="bg-slate-600 text-white text-xs px-2 py-1 rounded hover:bg-slate-500 transition"
                                title="Reply"
                            >
                                ↩️ Reply
                            </button>

                            {/* DELETE BUTTON (Only show if YOU sent the message) */}
                            {message?.senderId === authUser?._id && (
                                <button 
                                    onClick={handleDelete}
                                    className="bg-red-600 text-white text-xs px-2 py-1 rounded hover:bg-red-700 transition"
                                    title="Delete"
                                >
                                    🗑️ Delete
                                </button>
                            )}
                        </div>
                    )}

                    {/* SHOW REPLY QUOTE INSIDE CHAT BUBBLE */}
                    {message?.replyTo && (
                        <div className={`text-xs mb-1 px-2 py-1 border-l-4 rounded-sm ${
                            authUser?._id === message?.senderId ? 'border-slate-900 bg-black/10 text-slate-800' : 'border-cyan-400 bg-black/20 text-cyan-200'
                        }`}>
                            <p className="font-bold">{message.replyTo.username}</p>
                            <p className="truncate">{message.replyTo.text}</p>
                        </div>
                    )}

                    {message?.message && <p>{message?.message}</p>}

                    {message?.fileUrl && message?.fileType === "image" && (
                        <img src={message?.fileUrl} alt="sent" className="rounded-lg max-w-full mt-1 cursor-pointer max-h-[300px] object-cover" onClick={() => window.open(message?.fileUrl, "_blank")} />
                    )}

                    {message?.fileUrl && message?.fileType === "video" && (
                        <video controls className="rounded-lg max-w-full mt-1 max-h-[300px]" src={message?.fileUrl} />
                    )}

                    {message?.fileUrl && (message?.fileType === "file" || message?.fileType === "pdf") && (
                        <a href={message?.fileUrl} target="_blank" rel="noreferrer" className="flex items-center gap-2 underline text-sm mt-1 font-semibold" style={{ color: authUser?._id === message?.senderId ? '#1e293b' : '#93c5fd' }} download>
                            📄 Download File
                        </a>
                    )}

                </div>
            </div>
        </div>
    )
}