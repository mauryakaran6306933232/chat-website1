// import React from 'react' 
// import {IoSend} from 'react-icons/io5'
// import axios from 'axios'
// import Store from '../redux/store'
// import toast from 'react-hot-toast'
// import { useState } from 'react'
// import { useSelector  , useDispatch } from 'react-redux'
// import { setMessageSlice } from '../redux/messageSlice'
// export default function SendInput() {
//   const dispatch = useDispatch();
//   const {message} = useSelector(Store=>Store.message);
//   const [message1 , setMessage] = useState('');
//      const {selectedUser} = useSelector(Store=>Store.user);
//      const onSubmitHandler = async(e)=>{
//         e.preventDefault();
//         // alert(message);
//       try{
//         const res = await axios.post(`http://localhost:8001/test/sendMessage/${selectedUser?._id}`,{
//           message : message1
//         },
//         {
//           headers : {
//             'Content-Type' : 'application/json'
//           },
//           withCredentials : true
//         }
//       );
//       console.log('needed message is', message);
//        if(message == null){


//       dispatch(setMessageSlice([ res?.data?.newMessage]))
//        }
//        else{
//                 dispatch(setMessageSlice([...message , res?.data?.newMessage]))
//        }


//       if(!res){
//         console.log(res);
//       }
//       if(res?.data?.success){
//          toast.success('send message successfully');
//         setMessage("");
//         console.log('new Message is',res.data.newMessage)
//         const n2=res.data.newMessage
//         console.log("message is not iteravble ",message)
//         dispatch(setMessageSlice([...message,n2]))
//         console.log('send message', n2);
//       }
//     } 
//     catch(error){
//       toast.error(error?.response?.data?.message);
//       console.log(error);
//     }
//      }
//   return (
//    <form onSubmit={(e)=>{onSubmitHandler(e)}} className='px-4 my-3'>
//     <div className='w-full relative'>
//         <input
//         type='text'
//         placeholder='send a message....'
//         className='border p-3 border-zinc-500 text-sm rounded-lg block w-full bg-gray-600 text-white'
//         value={message1}
//         onChange={(e)=>{setMessage(e.target.value)}}
//         />
//         <button type="submit" className='absolute flex items-center inset-y-0 end-0'>
//             <IoSend/>
//         </button>
//     </div>
//    </form>
//   )
// }
// import React, { useState, useRef } from 'react' 
// import { IoSend } from 'react-icons/io5'
// import { IoAttach } from 'react-icons/io5'; // Added attach icon
// import axios from 'axios'
// import Store from '../redux/store'
// import toast from 'react-hot-toast'
// import { useSelector, useDispatch } from 'react-redux'
// import { setMessageSlice } from '../redux/messageSlice'

// export default function SendInput() {
//   const dispatch = useDispatch();
//   const { message } = useSelector(Store => Store.message);
//   const [message1, setMessage] = useState('');
//   const [selectedFile, setSelectedFile] = useState(null); // NEW: Track selected file
  
//   const { selectedUser } = useSelector(Store => Store.user);
//   const fileInputRef = useRef(null); // NEW: Ref to trigger file picker

//   const onSubmitHandler = async (e) => {
//     e.preventDefault();
//     if (!selectedUser) return toast.error("Select a user first");

//     // ==========================================
//     // FILE UPLOAD LOGIC
//     // ==========================================
//     if (selectedFile) {
//       const formData = new FormData();
//       formData.append("file", selectedFile); // "file" must match upload.single("file") in backend

//       try {
//         const res = await axios.post(
//           `http://localhost:8001/test/upload-file/${selectedUser._id}`,
//           formData,
//           {
//             headers: { "Content-Type": "multipart/form-data" },
//             withCredentials: true // CRITICAL: Sends your login cookie with the file
//           }
//         );

//         if (res.data.success) {
//           // Update Redux instantly so sender sees the file without waiting for socket
//           const currentMessages = message || [];
//           dispatch(setMessageSlice([...currentMessages, res.data.newMessage]));
          
//           toast.success("File sent!");
//           setSelectedFile(null);
//           if (fileInputRef.current) fileInputRef.current.value = ""; // Reset file input
//         }
//       } catch (error) {
//         toast.error(error?.response?.data?.message || "Failed to upload file");
//         console.log(error);
//       }
//       return; // Stop function here so it doesn't run the text message logic
//     }

//     // ==========================================
//     // TEXT MESSAGE LOGIC (Cleaned up)
//     // ==========================================
//     if (message1.trim() === "") return; // Don't send empty messages

//     try {
//       const res = await axios.post(
//         `http://localhost:8001/test/sendMessage/${selectedUser._id}`,
//         { message: message1 },
//         {
//           headers: { 'Content-Type': 'application/json' },
//           withCredentials: true
//         }
//       );

//       if (res?.data?.success) {
//         // Clean, single Redux update
//         const currentMessages = message || [];
//         dispatch(setMessageSlice([...currentMessages, res?.data?.newMessage]));
        
//         toast.success('Message sent');
//         setMessage(""); // Clear input
//       }
//     } catch (error) {
//       toast.error(error?.response?.data?.message);
//       console.log(error);
//     }
//   }

//   return (
//     <form onSubmit={(e) => { onSubmitHandler(e) }} className='px-4 my-3'>
//       <div className='w-full relative flex items-center'>
        
//         {/* Hidden File Input */}
//         <input
//           type="file"
//           ref={fileInputRef}
//           className="hidden"
//           onChange={(e) => setSelectedFile(e.target.files[0])}
//         />

//         {/* Attach File Button */}
//         <button 
//           type="button" 
//           onClick={() => fileInputRef.current.click()}
//           className='absolute left-3 text-zinc-400 hover:text-white transition-colors text-xl'
//           title="Attach file"
//         >
//           <IoAttach />
//         </button>

//         {/* Text Input (Added left padding so text doesn't overlap the 📎 icon) */}
//         <input
//           type='text'
//           placeholder='send a message....'
//           className='border p-3 pl-10 border-zinc-500 text-sm rounded-lg block w-full bg-gray-600 text-white'
//           value={selectedFile ? selectedFile.name : message1} // Show file name if selected
//           onChange={(e) => { setMessage(e.target.value) }}
//           readOnly={!!selectedFile} // Make input read-only if a file is selected
//         />

//         {/* Send Button */}
//         <button type="submit" className='absolute flex items-center inset-y-0 end-0 pr-3 text-zinc-400 hover:text-white transition-colors'>
//           <IoSend className="text-xl" />
//         </button>
//       </div>
//     </form>
//   )
// }
// import React, { useState, useRef, useEffect } from 'react' 
// import { IoSend } from 'react-icons/io5'
// import { IoAttach } from 'react-icons/io5';
// import { IoClose } from 'react-icons/io5'; // Import X icon to close reply box
// import axios from 'axios'
// import Store from '../redux/store'
// import toast from 'react-hot-toast'
// import { useSelector, useDispatch } from 'react-redux'
// import { setMessageSlice } from '../redux/messageSlice'
// import { clearReplySlice } from '../redux/replySlice'; // Import to clear the reply box

// export default function SendInput() {
//   const dispatch = useDispatch();
//   const { message } = useSelector(Store => Store.message);
//   const { selectedUser, authUser } = useSelector(Store => Store.user); // Added authUser for typing
//   const { socket } = useSelector(Store => Store.socket);
//   const { replyTo } = useSelector(Store => Store.reply); // Get reply state
  
//   const [message1, setMessage] = useState('');
//   const [selectedFile, setSelectedFile] = useState(null);
//   const fileInputRef = useRef(null);
//   const typingTimeoutRef = useRef(null);

//   // Cleanup typing timeout on unmount to prevent memory leaks
//   useEffect(() => {
//     return () => {
//       if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
//     }
//   }, []);

//   // Typing Handler
//   const handleTyping = () => {
//     if (!selectedUser || !socket) return;
    
//     // Emit typing event to receiver
//     socket.emit("typing", { to: selectedUser._id, from: authUser._id });

//     // Clear previous timeout and set a new one (stop emitting after 1.5s of inactivity)
//     if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
//     typingTimeoutRef.current = setTimeout(() => {}, 1500);
//   };

//   const onSubmitHandler = async (e) => {
//     e.preventDefault();
//     if (!selectedUser) return toast.error("Select a user first");

//     // ==========================================
//     // FILE UPLOAD LOGIC
//     // ==========================================
//     if (selectedFile) {
//       const formData = new FormData();
//       formData.append("file", selectedFile);

//       try {
//         const res = await axios.post(
//           `http://localhost:8001/test/upload-file/${selectedUser._id}`,
//           formData,
//           { headers: { "Content-Type": "multipart/form-data" }, withCredentials: true }
//         );

//         if (res.data.success) {
//           const currentMessages = message || [];
//           dispatch(setMessageSlice([...currentMessages, res.data.newMessage]));
//           toast.success("File sent!");
//           setSelectedFile(null);
//           if (fileInputRef.current) fileInputRef.current.value = "";
//           dispatch(clearReplySlice()); // Clear reply box after sending
//         }
//       } catch (error) {
//         toast.error(error?.response?.data?.message || "Failed to upload file");
//       }
//       return;
//     }

//     // ==========================================
//     // TEXT MESSAGE LOGIC
//     // ==========================================
//     if (message1.trim() === "") return;

//     try {
//       const res = await axios.post(
//         `http://localhost:8001/test/sendMessage/${selectedUser._id}`,
//         { 
//           message: message1,
//           replyTo: replyTo // <--- ATTACH REPLY DATA TO MESSAGE
//         },
//         { headers: { 'Content-Type': 'application/json' }, withCredentials: true }
//       );

//       if (res?.data?.success) {
//         const currentMessages = message || [];
//         dispatch(setMessageSlice([...currentMessages, res?.data?.newMessage]));
//         toast.success('Message sent');
//         setMessage(""); // Clear input
//         dispatch(clearReplySlice()); // <--- CLEAR REPLY BOX AFTER SENDING
//       }
//     } catch (error) {
//       toast.error(error?.response?.data?.message);
//     }
//   }

//   return (
//     <div className='px-4 my-3'>
//       {/* ==========================================
//            REPLY PREVIEW BOX (Shows above input)
//            ========================================== */}
//       {replyTo && (
//         <div className="mx-0 mb-2 flex items-center justify-between bg-slate-700 text-white text-sm p-2 rounded-t-lg border-l-4 border-cyan-400">
//           <div className="truncate pr-4 flex-1">
//             <span className="font-bold text-cyan-400">{replyTo.username}: </span>
//             <span className="text-gray-300">{replyTo.text}</span>
//           </div>
//           <button 
//             type="button" 
//             onClick={() => dispatch(clearReplySlice())} 
//             className="text-gray-400 hover:text-white font-bold p-1"
//           >
//             <IoClose size={20} />
//           </button>
//         </div>
//       )}

//       {/* ==========================================
//            MAIN INPUT FORM
//            ========================================== */}
//       <form onSubmit={(e) => { onSubmitHandler(e) }} className='flex items-center relative'>
        
//         {/* Hidden File Input */}
//         <input
//           type="file"
//           ref={fileInputRef}
//           className="hidden"
//           onChange={(e) => setSelectedFile(e.target.files[0])}
//         />

//         {/* Attach Button */}
//         <button 
//           type="button" 
//           onClick={() => fileInputRef.current.click()}
//           className='absolute left-3 text-zinc-400 hover:text-white transition-colors text-xl z-10'
//           title="Attach file"
//         >
//           <IoAttach />
//         </button>

//         {/* Text Input (Added left padding, and border-radius adjusts if reply box is visible) */}
//         <input
//           type='text'
//           placeholder={replyTo ? "Reply..." : 'send a message....'}
//           className={`border p-3 pl-10 border-zinc-500 text-sm block w-full bg-gray-600 text-white focus:outline-none focus:border-cyan-500 ${replyTo ? 'rounded-b-lg rounded-t-none' : 'rounded-lg'}`}
//           value={selectedFile ? selectedFile.name : message1}
//           onChange={(e) => { setMessage(e.target.value); handleTyping(); }}
//           readOnly={!!selectedFile}
//         />

//         {/* Send Button */}
//         <button 
//           type="submit" 
//           className='absolute flex items-center inset-y-0 end-0 pr-3 text-zinc-400 hover:text-white transition-colors z-10'
//         >
//           <IoSend className="text-xl" />
//         </button>
//       </form>
//     </div>
//   )
// }
import React, { useState, useRef, useEffect } from 'react' 
import { IoSend } from 'react-icons/io5'
import { IoAttach } from 'react-icons/io5';
import { IoClose } from 'react-icons/io5';
import axios from 'axios'
import Store from '../redux/store'
import toast from 'react-hot-toast'
import { useSelector, useDispatch } from 'react-redux'
import { setMessageSlice } from '../redux/messageSlice'
import { clearReplySlice } from '../redux/replySlice';

export default function SendInput() {
  const dispatch = useDispatch();
  const { message } = useSelector(Store => Store.message);
  const { selectedUser, authUser } = useSelector(Store => Store.user);
  const { socket } = useSelector(Store => Store.socket);
  const { replyTo } = useSelector(Store => Store.reply);
  
  const [message1, setMessage] = useState('');
  const [selectedFile, setSelectedFile] = useState(null);
  const [isLoading, setIsLoading] = useState(false); // <--- NEW: Loading State
  const fileInputRef = useRef(null);
  const typingTimeoutRef = useRef(null);

  useEffect(() => {
    return () => {
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    }
  }, []);

  const handleTyping = () => {
    if (!selectedUser || !socket) return;
    socket.emit("typing", { to: selectedUser._id, from: authUser._id });
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {}, 1500);
  };

  const onSubmitHandler = async (e) => {
    e.preventDefault();
    if (!selectedUser) return toast.error("Select a user first");
    if (isLoading) return; // <--- NEW: Prevent double clicks while loading

    // ==========================================
    // FILE UPLOAD LOGIC
    // ==========================================
    if (selectedFile) {
      setIsLoading(true); // <--- START LOADING
      const formData = new FormData();
      formData.append("file", selectedFile);

      try {
        const res = await axios.post(
          `http://localhost:8001/test/upload-file/${selectedUser._id}`,
          formData,
          { headers: { "Content-Type": "multipart/form-data" }, withCredentials: true }
        );

        if (res.data.success) {
          const currentMessages = message || [];
          dispatch(setMessageSlice([...currentMessages, res.data.newMessage]));
          toast.success("File sent!");
          setSelectedFile(null);
          if (fileInputRef.current) fileInputRef.current.value = "";
          dispatch(clearReplySlice());
        }
      } catch (error) {
        toast.error(error?.response?.data?.message || "Failed to upload file");
      } finally {
        setIsLoading(false); // <--- STOP LOADING (Runs whether it succeeds or fails)
      }
      return;
    }

    // ==========================================
    // TEXT MESSAGE LOGIC
    // ==========================================
    if (message1.trim() === "") return;

    setIsLoading(true); // <--- START LOADING

    try {
      const res = await axios.post(
        `http://localhost:8001/test/sendMessage/${selectedUser._id}`,
        { 
          message: message1,
          replyTo: replyTo
        },
        { headers: { 'Content-Type': 'application/json' }, withCredentials: true }
      );

      if (res?.data?.success) {
        const currentMessages = message || [];
        dispatch(setMessageSlice([...currentMessages, res?.data?.newMessage]));
        toast.success('Message sent');
        setMessage("");
        dispatch(clearReplySlice());
      }
    } catch (error) {
      toast.error(error?.response?.data?.message);
    } finally {
      setIsLoading(false); // <--- STOP LOADING
    }
  }

  return (
    <div className='px-4 my-3'>
      {/* REPLY PREVIEW BOX */}
      {replyTo && (
        <div className="mx-0 mb-2 flex items-center justify-between bg-slate-700 text-white text-sm p-2 rounded-t-lg border-l-4 border-cyan-400">
          <div className="truncate pr-4 flex-1">
            <span className="font-bold text-cyan-400">{replyTo.username}: </span>
            <span className="text-gray-300">{replyTo.text}</span>
          </div>
          <button type="button" onClick={() => dispatch(clearReplySlice())} className="text-gray-400 hover:text-white font-bold p-1">
            <IoClose size={20} />
          </button>
        </div>
      )}

      {/* MAIN INPUT FORM */}
      <form onSubmit={(e) => { onSubmitHandler(e) }} className='flex items-center relative'>
        
        <input type="file" ref={fileInputRef} className="hidden" onChange={(e) => setSelectedFile(e.target.files[0])} />

        {/* Attach Button */}
        <button 
          type="button" 
          onClick={() => fileInputRef.current.click()}
          className='absolute left-3 text-zinc-400 hover:text-white transition-colors text-xl z-10'
          title="Attach file"
          disabled={isLoading} // Disable while sending
        >
          <IoAttach />
        </button>

        {/* Text Input */}
        <input
          type='text'
          placeholder={replyTo ? "Reply..." : 'send a message....'}
          className={`border p-3 pl-10 border-zinc-500 text-sm block w-full bg-gray-600 text-white focus:outline-none focus:border-cyan-500 ${replyTo ? 'rounded-b-lg rounded-t-none' : 'rounded-lg'} ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
          value={selectedFile ? selectedFile.name : message1}
          onChange={(e) => { setMessage(e.target.value); handleTyping(); }}
          readOnly={!!selectedFile || isLoading} // Disable typing while sending
        />

        {/* SEND BUTTON / LOADING SPINNER */}
        <button 
          type="submit" 
          disabled={isLoading} // Disable clicks while loading
          className={`absolute flex items-center inset-y-0 end-0 pr-3 transition-colors z-10 ${isLoading ? 'text-cyan-400' : 'text-zinc-400 hover:text-white'}`}
        >
          {isLoading ? (
            // 🔥 TAILWIND CSS SPINNER (Replaces the send icon while loading)
            <svg className="animate-spin h-5 w-5 text-current" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          ) : (
            <IoSend className="text-xl" />
          )}
        </button>
      </form>
    </div>
  )
}